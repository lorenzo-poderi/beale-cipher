# Task

Identify the **first physical line of the actual literary work** in the supplied Project Gutenberg excerpt.

The excerpt has already been removed from everything before the Gutenberg start marker. Therefore, do not assume that the first supplied line is the beginning of the work.

## What to exclude

Ignore material that is preliminary or editorial rather than the work itself, including:

- title and subtitle;
- author information;
- introductions and prefaces;
- acknowledgements;
- author, publisher or translator notes;
- editorial notes;
- illustrations or illustration captions;
- indexes, contents and summaries;
- character lists;
- chapter/book/canto lists;
- chapter, book or canto titles and subtitles;
- chapter introductions;
- chapter/book/canto numbering;
- dates or headings that describe the historical context rather than belonging to the work;
- Project Gutenberg or transcription notes;
- similar preliminary material.

## What counts as the beginning

Return the first line that a reader would encounter as part of the actual work after skipping the material above.

The work does **not** have to begin with narrative prose. Apply the same rule to:

- poetry;
- drama;
- essays;
- philosophical works;
- religious works;
- letters;
- verse;
- works divided into books or cantos;
- other literary works.

Do not require a complete grammatical sentence. The requested value is the **first physical line of the work**, exactly as it appears in the supplied text.

## Important rules

1. Use only the supplied excerpt. Do not use external knowledge to invent text or a line.
2. Preserve the original line exactly. Do not paraphrase, correct spelling, normalize punctuation, or merge lines.
3. `firstSentenceLine` is a **0-based index** into the supplied lines.
4. `firstSentence` must be exactly the content of that line.
5. If the actual beginning of the work is not present in the supplied excerpt, return `Not found`.
6. Do not select a title, heading, chapter title, preface, introduction, editorial note or similar preliminary element merely because it appears before the literary text.
7. If the work intentionally begins with a heading that is itself part of the work rather than a chapter/title heading, treat it according to its role in the work.
8. If uncertain, prefer `Not found` over inventing or guessing a line.

## Output

Return only the requested structured result:

- `status`: `Done` when the beginning is found, otherwise `Not found`.
- `firstSentenceLine`: the 0-based line index, or `null`.
- `firstSentence`: the exact original line, or `null`.
- `confidence`: a number from `0` to `1`, where values near `1` indicate high confidence.
