# search-by-ai

Node.js 16 compatible implementation for detecting the first physical line of the actual work in a Project Gutenberg excerpt.

## Files

- `search-by-ai.js` - main script
- `prompt.md` - AI instructions
- `config.local.json` - local API configuration; do not commit it
- `.gitignore` - excludes the local configuration and logs

## Install

No npm package is required. The script uses Node.js built-in HTTPS support.

## Configuration

Copy `config.local.json` and put the OpenAI API key in it.

Alternatively set:

```text
OPENAI_API_KEY
```

The model can be supplied by the input; otherwise `defaultModel` is used.

## Preferred invocation

This is the interface expected by `search-single-book.js`:

```text
echo {"id":1,"lines":["line 0","line 1"],"modelName":"gpt-5.5","simulate":false} | node search-by-ai.js
```

For a real ebook excerpt, `lines` should contain the physical lines exactly as read from the ebook.

## Simulation

```text
node search-by-ai.js 1 sample.txt gpt-5.5 true
```

Simulation does not call OpenAI and returns a randomly selected non-empty line.

## Direct invocation

```text
node search-by-ai.js 1 sample.txt gpt-5.5 false
```

## Output

Success:

```json
{
  "id": 1,
  "status": "Done",
  "firstSentenceLine": 63,
  "firstSentence": "When in the Course of human events, it becomes necessary for one people",
  "confidence": 0.99,
  "tokenInput": 100,
  "tokenOutput": 200
}
```

Not found:

```json
{
  "id": 1,
  "status": "Not found",
  "firstSentenceLine": null,
  "firstSentence": null,
  "confidence": null,
  "tokenInput": 100,
  "tokenOutput": 200
}
```

Errors include an additional `error` field.

## Verification

After receiving a successful AI result, the script checks that:

```text
lines[firstSentenceLine] === firstSentence
```

If not, the result becomes `Error`.

## Logs

Per-book logs:

```text
logs/log-1.txt
```

Token usage:

```text
logs/token-usage.csv
```

The CSV uses semicolon separators:

```text
id;status;token input;token output
```
