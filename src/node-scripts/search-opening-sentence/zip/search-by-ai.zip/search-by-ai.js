'use strict';

/*
 * search-by-ai.js
 *
 * Node.js 16 compatible.
 *
 * Input:
 *   1) Preferred: JSON via stdin
 *      {
 *        "id": 1,
 *        "lines": ["line 0", "line 1", "..."],
 *        "modelName": "MODEL_NAME",
 *        "simulate": false
 *      }
 *
 *   2) CLI:
 *      node search-by-ai.js <id> <txt-file> [modelName] [simulate]
 *
 * Configuration:
 *   config.local.json (API key, default model, prompt path, etc.)
 *
 * Output:
 *   JSON on stdout only.
 */

const fs = require('fs');
const path = require('path');
const https = require('https');

const SCRIPT_DIR = __dirname;

const CONFIG = {
    CONFIG_FILE: path.join(SCRIPT_DIR, 'config.local.json'),
    PROMPT_FILE: path.join(SCRIPT_DIR, 'prompt.md'),

    DEFAULT_MODEL: 'gpt-5.5',

    API_HOST: 'api.openai.com',
    API_PATH: '/v1/responses',

    REQUEST_TIMEOUT_MS: 5 * 60 * 1000,
    MAX_RETRIES: 2,

    LOG_DIRECTORY: path.join(SCRIPT_DIR, 'logs'),
    COST_CSV_FILE: path.join(SCRIPT_DIR, 'logs', 'token-usage.csv'),

    DEFAULT_SIMULATE: false
};

const RESULT_STATUSES = {
    DONE: 'Done',
    NOT_FOUND: 'Not found',
    ERROR: 'Error'
};


/* ============================================================
 * Logging
 * ============================================================ */

function timestamp() {
    const now = new Date();

    const y = now.getFullYear();
    const m = String(now.getMonth() + 1).padStart(2, '0');
    const d = String(now.getDate()).padStart(2, '0');

    const hh = String(now.getHours()).padStart(2, '0');
    const mm = String(now.getMinutes()).padStart(2, '0');
    const ss = String(now.getSeconds()).padStart(2, '0');

    return `[${y}.${m}.${d} - ${hh}:${mm}:${ss}]`;
}

function createLogger(id) {
    fs.mkdirSync(CONFIG.LOG_DIRECTORY, { recursive: true });

    const file = path.join(CONFIG.LOG_DIRECTORY, `log-${id}.txt`);

    function write(message) {
        const line = `${timestamp()} ${message}\n`;

        fs.appendFileSync(file, line, 'utf8');
        console.error(line.trim());
    }

    return { write, file };
}


/* ============================================================
 * Configuration
 * ============================================================ */

function loadConfiguration() {
    if (!fs.existsSync(CONFIG.CONFIG_FILE)) {
        throw new Error(
            `Configuration file not found: ${CONFIG.CONFIG_FILE}`
        );
    }

    let config;

    try {
        config = JSON.parse(
            fs.readFileSync(CONFIG.CONFIG_FILE, 'utf8')
        );
    } catch (error) {
        throw new Error(
            `Unable to read configuration file: ${error.message}`
        );
    }

    return config;
}

function loadPrompt() {
    if (!fs.existsSync(CONFIG.PROMPT_FILE)) {
        throw new Error(
            `Prompt file not found: ${CONFIG.PROMPT_FILE}`
        );
    }

    return fs.readFileSync(CONFIG.PROMPT_FILE, 'utf8').trim();
}


/* ============================================================
 * Input
 * ============================================================ */

function parseBoolean(value, defaultValue) {
    if (value === undefined || value === null || value === '') {
        return defaultValue;
    }

    if (typeof value === 'boolean') {
        return value;
    }

    const normalized = String(value).trim().toLowerCase();

    if (['true', '1', 'yes', 'y'].includes(normalized)) {
        return true;
    }

    if (['false', '0', 'no', 'n'].includes(normalized)) {
        return false;
    }

    throw new Error(`Invalid simulate value: "${value}"`);
}

function parseCommandLine(args) {
    if (args.length === 0) {
        return null;
    }

    /*
     * Positional form:
     * node search-by-ai.js <id> <txt-file> [modelName] [simulate]
     */
    if (!args[0].startsWith('--')) {
        const id = Number(args[0]);

        if (!Number.isInteger(id) || id < 1 || id > 80000) {
            throw new Error(
                `Invalid ebook id "${args[0]}".`
            );
        }

        const txtFile = args[1];

        if (!txtFile) {
            throw new Error(
                'Missing text file.'
            );
        }

        const lines = fs.readFileSync(
            path.resolve(txtFile),
            'utf8'
        ).split(/\r?\n/);

        return {
            id,
            lines,
            modelName: args[2],
            simulate: parseBoolean(
                args[3],
                CONFIG.DEFAULT_SIMULATE
            )
        };
    }

    const result = {};

    for (let i = 0; i < args.length; i++) {
        const arg = args[i];

        if (arg === '--id') {
            result.id = Number(args[++i]);
        } else if (arg === '--txt') {
            result.txt = args[++i];
        } else if (arg === '--input-file') {
            result.inputFile = args[++i];
        } else if (arg === '--modelName' || arg === '--model') {
            result.modelName = args[++i];
        } else if (arg === '--simulate') {
            result.simulate = parseBoolean(
                args[++i],
                CONFIG.DEFAULT_SIMULATE
            );
        } else {
            throw new Error(`Unknown argument: ${arg}`);
        }
    }

    if (result.inputFile) {
        result.lines = fs.readFileSync(
            path.resolve(result.inputFile),
            'utf8'
        ).split(/\r?\n/);
    } else if (typeof result.txt === 'string') {
        result.lines = result.txt.split(/\r?\n/);
    }

    return result;
}

function parseStdinJson(text) {
    if (!text || !text.trim()) {
        return null;
    }

    let input;

    try {
        input = JSON.parse(text);
    } catch (error) {
        throw new Error(
            `Invalid JSON received via stdin: ${error.message}`
        );
    }

    const result = {
        id: input.id,
        modelName: input.modelName,
        simulate: parseBoolean(
            input.simulate,
            CONFIG.DEFAULT_SIMULATE
        )
    };

    if (Array.isArray(input.lines)) {
        result.lines = input.lines.map(value => String(value));
    } else if (typeof input.txt === 'string') {
        result.lines = input.txt.split(/\r?\n/);
    }

    return result;
}

async function readInput() {
    const commandLine = parseCommandLine(
        process.argv.slice(2)
    );

    /*
     * If command line parameters were supplied, use them.
     * Otherwise read JSON from stdin.
     */
    if (commandLine) {
        return commandLine;
    }

    const stdin = await readAllStdin();

    return parseStdinJson(stdin);
}

function readAllStdin() {
    return new Promise((resolve, reject) => {
        let data = '';

        process.stdin.setEncoding('utf8');

        process.stdin.on('data', chunk => {
            data += chunk;
        });

        process.stdin.on('end', () => resolve(data));

        process.stdin.on('error', reject);
    });
}


/* ============================================================
 * Validation
 * ============================================================ */

function validateInput(input) {
    if (!input || typeof input !== 'object') {
        throw new Error('No input received.');
    }

    const id = Number(input.id);

    if (!Number.isInteger(id) || id < 1 || id > 80000) {
        throw new Error(
            `Invalid ebook id "${input.id}". Expected 1..80000.`
        );
    }

    if (!Array.isArray(input.lines)) {
        throw new Error(
            'Input text is missing. Expected "lines" or "txt".'
        );
    }

    if (input.lines.length === 0) {
        throw new Error('Input text is empty.');
    }

    if (!input.lines.some(line => String(line).trim().length > 0)) {
        throw new Error('Input text contains no non-empty lines.');
    }

    return {
        id,
        lines: input.lines.map(line => String(line)),
        modelName: input.modelName,
        simulate: Boolean(input.simulate)
    };
}


/* ============================================================
 * Results
 * ============================================================ */

function errorResult(id, message, usage) {
    return {
        id,
        status: RESULT_STATUSES.ERROR,
        firstSentenceLine: null,
        firstSentence: null,
        confidence: null,
        tokenInput: usage && Number.isInteger(usage.input) ? usage.input : null,
        tokenOutput: usage && Number.isInteger(usage.output) ? usage.output : null,
        error: message
    };
}

function notFoundResult(id, usage) {
    return {
        id,
        status: RESULT_STATUSES.NOT_FOUND,
        firstSentenceLine: null,
        firstSentence: null,
        confidence: null,
        tokenInput: usage && Number.isInteger(usage.input) ? usage.input : null,
        tokenOutput: usage && Number.isInteger(usage.output) ? usage.output : null
    };
}


/* ============================================================
 * Simulation
 * ============================================================ */

function simulateSearch(id, lines) {
    const candidates = [];

    for (let i = 0; i < lines.length; i++) {
        if (lines[i].trim().length > 0) {
            candidates.push(i);
        }
    }

    if (candidates.length === 0) {
        return notFoundResult(id, {
            input: 0,
            output: 0
        });
    }

    const selectedIndex =
        candidates[Math.floor(Math.random() * candidates.length)];

    return {
        id,
        status: RESULT_STATUSES.DONE,
        firstSentenceLine: selectedIndex,
        firstSentence: lines[selectedIndex],
        confidence: 0.5,
        tokenInput: 0,
        tokenOutput: 0
    };
}


/* ============================================================
 * OpenAI API
 * ============================================================ */

function postJson({
    apiKey,
    body,
    timeoutMs
}) {
    return new Promise((resolve, reject) => {
        const payload = JSON.stringify(body);

        const request = https.request(
            {
                hostname: CONFIG.API_HOST,
                path: CONFIG.API_PATH,
                method: 'POST',
                timeout: timeoutMs,
                headers: {
                    'Authorization': `Bearer ${apiKey}`,
                    'Content-Type': 'application/json',
                    'Content-Length': Buffer.byteLength(payload)
                }
            },
            response => {
                let data = '';

                response.setEncoding('utf8');

                response.on('data', chunk => {
                    data += chunk;
                });

                response.on('end', () => {
                    let parsed;

                    try {
                        parsed = JSON.parse(data);
                    } catch (error) {
                        reject(
                            new Error(
                                `OpenAI returned invalid JSON (HTTP ${response.statusCode}).`
                            )
                        );
                        return;
                    }

                    if (
                        response.statusCode < 200 ||
                        response.statusCode >= 300
                    ) {
                        const apiMessage =
                            parsed &&
                            parsed.error &&
                            parsed.error.message
                                ? parsed.error.message
                                : `HTTP ${response.statusCode}`;

                        const error = new Error(
                            `OpenAI API error: ${apiMessage}`
                        );

                        error.statusCode = response.statusCode;
                        error.apiResponse = parsed;

                        reject(error);
                        return;
                    }

                    resolve(parsed);
                });
            }
        );

        request.on('timeout', () => {
            request.destroy(
                new Error(
                    `OpenAI request timed out after ${timeoutMs} ms.`
                )
            );
        });

        request.on('error', reject);

        request.write(payload);
        request.end();
    });
}

function isRetryableApiError(error) {
    if (!error || !error.statusCode) {
        return true;
    }

    return (
        error.statusCode === 408 ||
        error.statusCode === 409 ||
        error.statusCode === 429 ||
        error.statusCode >= 500
    );
}

async function callOpenAI({
    apiKey,
    modelName,
    prompt,
    text,
    logger
}) {
    const userContent =
        'Analyze the following ebook excerpt.\n\n' +
        'IMPORTANT: The line numbers shown below are 0-based and are part of the input. ' +
        'Return the line number from this exact excerpt.\n\n' +
        text;

    const schema = {
        type: 'object',
        additionalProperties: false,
        properties: {
            status: {
                type: 'string',
                enum: ['Done', 'Not found']
            },
            firstSentenceLine: {
                type: ['integer', 'null']
            },
            firstSentence: {
                type: ['string', 'null']
            },
            confidence: {
                type: ['number', 'null']
            }
        },
        required: [
            'status',
            'firstSentenceLine',
            'firstSentence',
            'confidence'
        ]
    };

    const body = {
        model: modelName,
        instructions: prompt,
        input: userContent,
        text: {
            format: {
                type: 'json_schema',
                name: 'ebook_start_detection',
                strict: true,
                schema
            }
        }
    };

    let lastError = null;

    for (let attempt = 0; attempt <= CONFIG.MAX_RETRIES; attempt++) {
        try {
            logger.write(
                `Calling OpenAI API with model ${modelName} (attempt ${attempt + 1})`
            );

            return await postJson({
                apiKey,
                body,
                timeoutMs: CONFIG.REQUEST_TIMEOUT_MS
            });
        } catch (error) {
            lastError = error;

            logger.write(
                `OpenAI API error: ${error.message}`
            );

            if (
                attempt >= CONFIG.MAX_RETRIES ||
                !isRetryableApiError(error)
            ) {
                break;
            }

            const delayMs = Math.pow(2, attempt) * 1000;

            logger.write(
                `Retrying OpenAI request in ${delayMs} ms...`
            );

            await delay(delayMs);
        }
    }

    throw lastError;
}

function delay(ms) {
    return new Promise(resolve => setTimeout(resolve, ms));
}


/* ============================================================
 * OpenAI response parsing
 * ============================================================ */

function getOutputText(response) {
    if (typeof response.output_text === 'string') {
        return response.output_text;
    }

    /*
     * Defensive fallback for response structures where output_text
     * is not directly exposed.
     */
    if (Array.isArray(response.output)) {
        const chunks = [];

        for (const item of response.output) {
            if (
                item &&
                item.type === 'message' &&
                Array.isArray(item.content)
            ) {
                for (const content of item.content) {
                    if (
                        content &&
                        content.type === 'output_text' &&
                        typeof content.text === 'string'
                    ) {
                        chunks.push(content.text);
                    }
                }
            }
        }

        if (chunks.length > 0) {
            return chunks.join('');
        }
    }

    return null;
}

function parseAiOutput(response) {
    const outputText = getOutputText(response);

    if (!outputText) {
        throw new Error(
            'OpenAI response does not contain output text.'
        );
    }

    let parsed;

    try {
        parsed = JSON.parse(outputText);
    } catch (error) {
        throw new Error(
            `AI output is not valid JSON: ${error.message}`
        );
    }

    return {
        result: parsed,
        usage: {
            input:
                response.usage &&
                Number.isInteger(response.usage.input_tokens)
                    ? response.usage.input_tokens
                    : 0,

            output:
                response.usage &&
                Number.isInteger(response.usage.output_tokens)
                    ? response.usage.output_tokens
                    : 0
        }
    };
}


/* ============================================================
 * AI result validation and verification
 * ============================================================ */

function validateAiResult(result) {
    if (!result || typeof result !== 'object') {
        throw new Error('AI result is not an object.');
    }

    if (
        result.status !== RESULT_STATUSES.DONE &&
        result.status !== RESULT_STATUSES.NOT_FOUND
    ) {
        throw new Error(
            `Invalid AI status: "${result.status}".`
        );
    }

    if (result.status === RESULT_STATUSES.NOT_FOUND) {
        return;
    }

    if (
        !Number.isInteger(result.firstSentenceLine) ||
        result.firstSentenceLine < 0
    ) {
        throw new Error(
            'AI returned an invalid firstSentenceLine.'
        );
    }

    if (
        typeof result.firstSentence !== 'string' ||
        result.firstSentence.trim().length === 0
    ) {
        throw new Error(
            'AI returned an empty firstSentence.'
        );
    }

    if (
        typeof result.confidence !== 'number' ||
        !Number.isFinite(result.confidence) ||
        result.confidence < 0 ||
        result.confidence > 1
    ) {
        throw new Error(
            'AI returned an invalid confidence value.'
        );
    }
}

function verifyResult(result, lines) {
    if (result.status !== RESULT_STATUSES.DONE) {
        return;
    }

    const lineIndex = result.firstSentenceLine;

    if (
        lineIndex < 0 ||
        lineIndex >= lines.length
    ) {
        throw new Error(
            `firstSentenceLine ${lineIndex} is outside the supplied text.`
        );
    }

    /*
     * The specification requires the returned firstSentence
     * to correspond to the line indicated by firstSentenceLine.
     *
     * Comparison is intentionally exact.
     */
    if (lines[lineIndex] !== result.firstSentence) {
        throw new Error(
            `Verification failed: firstSentence does not exactly match ` +
            `line ${lineIndex}.`
        );
    }
}


/* ============================================================
 * Cost / usage CSV
 * ============================================================ */

function appendUsageCsv({
    id,
    status,
    tokenInput,
    tokenOutput
}) {
    fs.mkdirSync(CONFIG.LOG_DIRECTORY, { recursive: true });

    const file = CONFIG.COST_CSV_FILE;

    if (!fs.existsSync(file)) {
        fs.appendFileSync(
            file,
            'id;status;token input;token output\n',
            'utf8'
        );
    }

    fs.appendFileSync(
        file,
        `${id};${status};${tokenInput ?? ''};${tokenOutput ?? ''}\n`,
        'utf8'
    );
}


/* ============================================================
 * Main processing
 * ============================================================ */

async function process(input) {
    const logger = createLogger(input.id);

    logger.write('Reading text...');
    logger.write(`Lines received: ${input.lines.length}`);
    logger.write(`Simulation mode: ${input.simulate}`);

    if (input.simulate) {
        logger.write('Simulation enabled. No OpenAI API call will be made.');

        const result = simulateSearch(
            input.id,
            input.lines
        );

        logger.write(
            `Simulated first sentence found at line ${result.firstSentenceLine}: ` +
            `"${result.firstSentence}"`
        );

        logger.write(
            `Confidence: ${result.confidence}`
        );

        appendUsageCsv({
            id: input.id,
            status: result.status,
            tokenInput: 0,
            tokenOutput: 0
        });

        return result;
    }

    const config = loadConfiguration();
    const prompt = loadPrompt();

    const apiKey =
        config.apiKey ||
        process.env.OPENAI_API_KEY;

    if (!apiKey) {
        throw new Error(
            'OpenAI API key not configured. ' +
            'Set apiKey in config.local.json or OPENAI_API_KEY.'
        );
    }

    const modelName =
        input.modelName ||
        config.defaultModel ||
        CONFIG.DEFAULT_MODEL;

    const numberedText = input.lines
        .map((line, index) => `${index}: ${line}`)
        .join('\n');

    logger.write(
        `Calling API with model ${modelName}`
    );

    const response = await callOpenAI({
        apiKey,
        modelName,
        prompt,
        text: numberedText,
        logger
    });

    const parsed = parseAiOutput(response);

    const tokenInput = parsed.usage.input;
    const tokenOutput = parsed.usage.output;

    logger.write(
        `Token (input): ${tokenInput}`
    );

    logger.write(
        `Token (output): ${tokenOutput}`
    );

    const aiResult = parsed.result;

    validateAiResult(aiResult);

    if (aiResult.status === RESULT_STATUSES.NOT_FOUND) {
        const result = notFoundResult(
            input.id,
            parsed.usage
        );

        logger.write(
            'First sentence not found.'
        );

        appendUsageCsv({
            id: input.id,
            status: result.status,
            tokenInput,
            tokenOutput
        });

        return result;
    }

    try {
        verifyResult(
            aiResult,
            input.lines
        );
    } catch (error) {
        logger.write(
            `ERROR: ${error.message}`
        );

        const result = errorResult(
            input.id,
            error.message,
            parsed.usage
        );

        appendUsageCsv({
            id: input.id,
            status: result.status,
            tokenInput,
            tokenOutput
        });

        return result;
    }

    const result = {
        id: input.id,
        status: RESULT_STATUSES.DONE,
        firstSentenceLine: aiResult.firstSentenceLine,
        firstSentence: aiResult.firstSentence,
        confidence: aiResult.confidence,
        tokenInput,
        tokenOutput
    };

    logger.write(
        `First sentence found: "${result.firstSentence}"`
    );

    logger.write(
        `First sentence line: ${result.firstSentenceLine}`
    );

    logger.write(
        `Confidence: ${result.confidence}`
    );

    logger.write(
        'Verification: OK'
    );

    appendUsageCsv({
        id: input.id,
        status: result.status,
        tokenInput,
        tokenOutput
    });

    return result;
}


/* ============================================================
 * Entry point
 * ============================================================ */

async function main() {
    let input;

    try {
        input = await readInput();
        input = validateInput(input);

        const result = await process(input);

        process.stdout.write(
            JSON.stringify(result, null, 2)
        );
    } catch (error) {
        const id =
            input && Number.isInteger(Number(input.id))
                ? Number(input.id)
                : null;

        /*
         * If we have an ebook id, write the error to its log.
         */
        if (id !== null) {
            try {
                const logger = createLogger(id);

                logger.write(
                    `ERROR: ${error.stack || error.message}`
                );
            } catch (_) {
                // Do not hide the original error.
            }
        }

        const result = errorResult(
            id,
            error.message,
            null
        );

        process.stdout.write(
            JSON.stringify(result, null, 2)
        );

        process.exitCode = 0;
    }
}

main();
