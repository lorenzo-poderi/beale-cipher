'use strict';

const fs = require('fs');
const path = require('path');
const { spawn } = require('child_process');

/*
 * ============================================================
 * CONFIGURATION
 * ============================================================
 */

const CONFIG = {
    // Numero di righe del primo tentativo
    FIRST_SAMPLE_LINES: 500,

    // Numero di righe del secondo tentativo
    SECOND_SAMPLE_LINES: 1000,

    // Numero massimo di tentativi
    MAX_ATTEMPTS: 2,

    // Marker utilizzato da Project Gutenberg
    GUTENBERG_MARKER: '*** START OF THE PROJECT GUTENBERG EBOOK',

    // Script che esegue la ricerca tramite AI
    AI_SCRIPT: path.join(__dirname, 'search-by-ai.js'),

    // Timeout massimo per una chiamata a search-by-ai.js
    AI_TIMEOUT_MS: 5 * 60 * 1000,

    // Encoding dei file Gutenberg
    FILE_ENCODING: 'utf8',

    // Directory dei log.
    // Se non viene specificata una directory assoluta,
    // i log vengono creati nella directory dello script.
    LOG_DIRECTORY: path.join(__dirname, 'logs')
};


/*
 * ============================================================
 * LOGGING
 * ============================================================
 */

function getTimestamp() {
    const now = new Date();

    const year = now.getFullYear();
    const month = String(now.getMonth() + 1).padStart(2, '0');
    const day = String(now.getDate()).padStart(2, '0');

    const hours = String(now.getHours()).padStart(2, '0');
    const minutes = String(now.getMinutes()).padStart(2, '0');
    const seconds = String(now.getSeconds()).padStart(2, '0');

    return `[${year}.${month}.${day} - ${hours}:${minutes}:${seconds}]`;
}


function createLogger(bookId) {
    if (!fs.existsSync(CONFIG.LOG_DIRECTORY)) {
        fs.mkdirSync(CONFIG.LOG_DIRECTORY, {
            recursive: true
        });
    }

    const logFile = path.join(
        CONFIG.LOG_DIRECTORY,
        `log-${bookId}.txt`
    );

    function write(message) {
        const line = `${getTimestamp()} ${message}\n`;

        fs.appendFileSync(
            logFile,
            line,
            {
                encoding: 'utf8'
            }
        );

        // Manteniamo anche il log sulla console
        console.log(line.trim());
    }

    return {
        write,
        file: logFile
    };
}


/*
 * ============================================================
 * VALIDATION
 * ============================================================
 */

function validateArguments(args) {
    if (args.length < 2) {
        throw new Error(
            'Usage: node search-single-book.js <ebook-id> <ebook-path>'
        );
    }

    const id = Number(args[0]);

    if (!Number.isInteger(id) || id < 1 || id > 80000) {
        throw new Error(
            `Invalid ebook id "${args[0]}". Expected an integer between 1 and 80000.`
        );
    }

    const ebookPath = args[1];

    if (!ebookPath || ebookPath.trim().length === 0) {
        throw new Error('Ebook path cannot be empty.');
    }

    return {
        id,
        ebookPath
    };
}


/*
 * ============================================================
 * FILE READING
 * ============================================================
 */

async function readEbook(ebookPath) {
    return fs.promises.readFile(
        ebookPath,
        {
            encoding: CONFIG.FILE_ENCODING
        }
    );
}


/*
 * ============================================================
 * GUTENBERG MARKER
 * ============================================================
 */

function findGutenbergMarker(lines) {
    for (let i = 0; i < lines.length; i++) {
        if (lines[i].includes(CONFIG.GUTENBERG_MARKER)) {
            return i;
        }
    }

    return -1;
}


/*
 * ============================================================
 * SAMPLE EXTRACTION
 * ============================================================
 */

function extractSample(lines, markerLine, numberOfLines) {
    const startLine = markerLine + 1;

    const endLine = Math.min(
        startLine + numberOfLines,
        lines.length
    );

    return {
        lines: lines.slice(startLine, endLine),
        startLine,
        endLine: endLine - 1
    };
}


/*
 * ============================================================
 * AI SCRIPT INVOCATION
 * ============================================================
 *
 * search-by-ai.js riceve un JSON tramite stdin:
 *
 * {
 *   "id": 1,
 *   "lines": [...]
 * }
 *
 * e deve restituire un JSON tramite stdout.
 *
 * Esempio:
 *
 * {
 *   "id": 1,
 *   "status": "Done",
 *   "firstSentenceLine": 42,
 *   "firstSentence": "...",
 *   "confidence": 0.99
 * }
 *
 * ============================================================
 */

function callSearchByAi(bookId, sampleLines, logger) {
    return new Promise((resolve, reject) => {

        logger.write(
            `Starting search-by-ai.js with ${sampleLines.length} lines...`
        );

        const child = spawn(
            process.execPath,
            [CONFIG.AI_SCRIPT],
            {
                stdio: ['pipe', 'pipe', 'pipe'],
                windowsHide: true
            }
        );

        let stdout = '';
        let stderr = '';
        let finished = false;

        const timeout = setTimeout(() => {

            if (finished) {
                return;
            }

            finished = true;

            logger.write(
                `ERROR: search-by-ai.js timeout after ${CONFIG.AI_TIMEOUT_MS} ms`
            );

            child.kill();

            reject(
                new Error(
                    `search-by-ai.js timeout after ${CONFIG.AI_TIMEOUT_MS} ms`
                )
            );

        }, CONFIG.AI_TIMEOUT_MS);


        child.stdout.setEncoding('utf8');

        child.stdout.on('data', data => {
            stdout += data;
        });


        child.stderr.setEncoding('utf8');

        child.stderr.on('data', data => {
            stderr += data;
        });


        child.on('error', error => {

            if (finished) {
                return;
            }

            finished = true;

            clearTimeout(timeout);

            reject(error);
        });


        child.on('close', code => {

            if (finished) {
                return;
            }

            finished = true;

            clearTimeout(timeout);

            if (code !== 0) {

                logger.write(
                    `ERROR: search-by-ai.js exited with code ${code}`
                );

                if (stderr.trim()) {
                    logger.write(
                        `AI stderr: ${stderr.trim()}`
                    );
                }

                reject(
                    new Error(
                        `search-by-ai.js exited with code ${code}`
                    )
                );

                return;
            }


            if (!stdout.trim()) {

                reject(
                    new Error(
                        'search-by-ai.js returned an empty response.'
                    )
                );

                return;
            }


            let result;

            try {
                result = JSON.parse(stdout);
            }
            catch (error) {

                logger.write(
                    `ERROR: Invalid JSON returned by search-by-ai.js`
                );

                logger.write(
                    `AI output: ${stdout.trim()}`
                );

                reject(
                    new Error(
                        'search-by-ai.js returned invalid JSON.'
                    )
                );

                return;
            }


            resolve(result);
        });


        /*
         * Passiamo l'input allo script AI.
         *
         * Non utilizziamo command line arguments per il testo
         * perché il campione può essere molto grande.
         */

        const input = {
            id: bookId,
            lines: sampleLines
        };

        child.stdin.write(
            JSON.stringify(input)
        );

        child.stdin.end();
    });
}


/*
 * ============================================================
 * AI RESULT VALIDATION
 * ============================================================
 */

function validateAiResult(result, bookId) {

    if (!result || typeof result !== 'object') {
        throw new Error(
            'Invalid result returned by search-by-ai.js.'
        );
    }

    if (result.id !== undefined && Number(result.id) !== bookId) {
        throw new Error(
            `AI result contains unexpected ebook id "${result.id}".`
        );
    }


    if (!result.status) {
        throw new Error(
            'AI result does not contain a status.'
        );
    }


    const validStatuses = [
        'Done',
        'Not found',
        'Error'
    ];

    if (!validStatuses.includes(result.status)) {
        throw new Error(
            `Invalid AI status "${result.status}".`
        );
    }


    if (result.status === 'Done') {

        if (!Number.isInteger(result.firstSentenceLine)) {
            throw new Error(
                'AI returned status "Done" but firstSentenceLine is invalid.'
            );
        }

        if (
            typeof result.firstSentence !== 'string' ||
            result.firstSentence.trim().length === 0
        ) {
            throw new Error(
                'AI returned status "Done" but firstSentence is empty.'
            );
        }

        if (
            typeof result.confidence !== 'number' ||
            result.confidence < 0 ||
            result.confidence > 1
        ) {
            throw new Error(
                'AI returned status "Done" but confidence is invalid.'
            );
        }
    }
}


/*
 * ============================================================
 * RESULT BUILDING
 * ============================================================
 */

function createNotFoundResult(bookId, markerLine) {
    return {
        id: bookId,
        status: 'Not found',
        trimmedLines: markerLine,
        firstSentenceLine: null,
        confidence: null,
        firstSentence: null
    };
}


function createErrorResult(bookId, markerLine) {
    return {
        id: bookId,
        status: 'Error',
        trimmedLines: markerLine,
        firstSentenceLine: null,
        confidence: null,
        firstSentence: null
    };
}


function createDoneResult(
    bookId,
    markerLine,
    aiResult
) {
    /*
     * search-by-ai restituisce una riga relativa al campione.
     *
     * Il campione inizia dalla riga immediatamente successiva
     * al Gutenberg marker.
     *
     * Quindi:
     *
     * originalLine =
     *     markerLine
     *     + 1
     *     + relativeLine
     */

    const originalLine =
        markerLine +
        1 +
        aiResult.firstSentenceLine;


    return {
        id: bookId,
        status: 'Done',
        trimmedLines: markerLine,
        firstSentenceLine: originalLine,
        confidence: aiResult.confidence,
        firstSentence: aiResult.firstSentence
    };
}


/*
 * ============================================================
 * MAIN PROCESSING
 * ============================================================
 */

async function processBook(bookId, ebookPath, logger) {

    logger.write('Reading file...');
    logger.write(`Ebook path: ${ebookPath}`);


    /*
     * --------------------------------------------------------
     * Check file
     * --------------------------------------------------------
     */

    try {
        await fs.promises.access(
            ebookPath,
            fs.constants.R_OK
        );
    }
    catch (error) {

        logger.write(
            `ERROR: Ebook file cannot be accessed.`
        );

        return createErrorResult(bookId, null);
    }


    /*
     * --------------------------------------------------------
     * Read file
     * --------------------------------------------------------
     */

    let content;

    try {
        content = await readEbook(ebookPath);
    }
    catch (error) {

        logger.write(
            `ERROR: Unable to read ebook: ${error.message}`
        );

        return createErrorResult(bookId, null);
    }


    /*
     * --------------------------------------------------------
     * Split into lines
     * --------------------------------------------------------
     */

    const lines = content.split(/\r?\n/);

    logger.write(
        `File read successfully. Total lines: ${lines.length}`
    );


    /*
     * --------------------------------------------------------
     * Find Gutenberg marker
     * --------------------------------------------------------
     */

    const markerLine = findGutenbergMarker(lines);

    if (markerLine === -1) {

        logger.write(
            `Gutenberg marker not found.`
        );

        return createNotFoundResult(
            bookId,
            null
        );
    }


    logger.write(
        `Gutenberg marker found at line ${markerLine}`
    );


    /*
     * --------------------------------------------------------
     * AI attempts
     * --------------------------------------------------------
     */

    const sampleSizes = [
        CONFIG.FIRST_SAMPLE_LINES,
        CONFIG.SECOND_SAMPLE_LINES
    ];


    for (
        let attempt = 0;
        attempt < CONFIG.MAX_ATTEMPTS;
        attempt++
    ) {

        const requestedLines =
            sampleSizes[
                Math.min(
                    attempt,
                    sampleSizes.length - 1
                )
            ];


        const sample = extractSample(
            lines,
            markerLine,
            requestedLines
        );


        logger.write(
            `Attempt ${attempt + 1}/${CONFIG.MAX_ATTEMPTS}: ` +
            `extracting lines ${sample.startLine}-${sample.endLine}`
        );


        logger.write(
            `Sending ${sample.lines.length} lines to AI...`
        );


        let aiResult;

        try {

            aiResult = await callSearchByAi(
                bookId,
                sample.lines,
                logger
            );

            validateAiResult(
                aiResult,
                bookId
            );

        }
        catch (error) {

            logger.write(
                `ERROR during AI processing: ${error.message}`
            );

            return createErrorResult(
                bookId,
                markerLine
            );
        }


        /*
         * ----------------------------------------------------
         * AI: DONE
         * ----------------------------------------------------
         */

        if (aiResult.status === 'Done') {

            const result = createDoneResult(
                bookId,
                markerLine,
                aiResult
            );


            logger.write(
                `Start detected at local line ` +
                `${aiResult.firstSentenceLine}`
            );

            logger.write(
                `Original start line: ` +
                `${result.firstSentenceLine}`
            );

            logger.write(
                `Confidence: ${result.confidence}`
            );


            /*
             * Basic verification.
             *
             * Verifichiamo che la riga calcolata esista
             * effettivamente nel documento.
             */

            if (
                result.firstSentenceLine < 0 ||
                result.firstSentenceLine >= lines.length
            ) {

                logger.write(
                    `ERROR: Calculated firstSentenceLine ` +
                    `${result.firstSentenceLine} is outside the ebook.`
                );

                return createErrorResult(
                    bookId,
                    markerLine
                );
            }


            logger.write(
                `Verification: OK`
            );


            return result;
        }


        /*
         * ----------------------------------------------------
         * AI: NOT FOUND
         * ----------------------------------------------------
         */

        if (aiResult.status === 'Not found') {

            logger.write(
                `AI did not find the beginning of the work.`
            );


            /*
             * Se abbiamo ancora un tentativo disponibile,
             * il ciclo prosegue con 1000 righe.
             */

            if (attempt + 1 < CONFIG.MAX_ATTEMPTS) {

                logger.write(
                    `Retrying with a larger sample...`
                );

                continue;
            }


            /*
             * Nessun risultato dopo il numero massimo
             * di tentativi.
             */

            logger.write(
                `Maximum number of AI attempts reached.`
            );

            logger.write(
                `Manual search is required.`
            );


            return createNotFoundResult(
                bookId,
                markerLine
            );
        }


        /*
         * ----------------------------------------------------
         * AI: ERROR
         * ----------------------------------------------------
         */

        if (aiResult.status === 'Error') {

            logger.write(
                `search-by-ai.js returned status Error.`
            );

            return createErrorResult(
                bookId,
                markerLine
            );
        }
    }


    /*
     * Questo punto non dovrebbe mai essere raggiunto.
     */

    logger.write(
        `ERROR: Unexpected end of processing.`
    );

    return createErrorResult(
        bookId,
        markerLine
    );
}


/*
 * ============================================================
 * ENTRY POINT
 * ============================================================
 */

async function main() {

    let args;

    try {
        args = validateArguments(
            process.argv.slice(2)
        );
    }
    catch (error) {

        console.error(
            `ERROR: ${error.message}`
        );

        process.exitCode = 1;
        return;
    }


    const logger = createLogger(args.id);

    logger.write(
        `==================================================`
    );

    logger.write(
        `Starting search-single-book for ebook ${args.id}`
    );

    logger.write(
        `==================================================`
    );


    let result;

    try {

        result = await processBook(
            args.id,
            args.ebookPath,
            logger
        );

    }
    catch (error) {

        logger.write(
            `UNHANDLED ERROR: ${error.stack || error.message}`
        );

        result = createErrorResult(
            args.id,
            null
        );
    }


    logger.write(
        `Processing completed with status: ${result.status}`
    );

    logger.write(
        `Result: ${JSON.stringify(result)}`
    );

    logger.write(
        `==================================================`
    );


    /*
     * Il JSON viene scritto esclusivamente su stdout.
     *
     * Questo è importante perché search-orchestrator.js
     * potrà richiamare questo script e leggere direttamente
     * il risultato.
     */

    process.stdout.write(
        JSON.stringify(result, null, 2)
    );
}


main();