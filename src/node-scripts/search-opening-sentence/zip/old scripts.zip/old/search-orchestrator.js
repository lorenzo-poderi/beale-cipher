'use strict';

const fs = require('fs');
const path = require('path');
const { spawn } = require('child_process');


/*
 * ============================================================
 * ENTRY POINT
 * ============================================================
 */

async function main() {

    let args;

    try {
        args = validateArguments(
            process.argv.slice(2)
        );
    }
    catch (error) {

        console.error(
            `ERROR: ${error.message}`
        );

        process.exitCode = 1;
        return;
    }

    let result = { "status": "ok"}


    /*
     * Il JSON viene scritto esclusivamente su stdout.
     *
     * Questo è importante perché search-orchestrator.js
     * potrà richiamare questo script e leggere direttamente
     * il risultato.
     */

    process.stdout.write(
        JSON.stringify(result, null, 2)
    );
}


main();