# Gutenberg Search - modular Node.js

The three logical stages remain, but they are modules rather than independent processes:

- `src/orchestrator.js` - chooses/processes ebook IDs
- `src/book-search.js` - reads one ebook, finds the Gutenberg marker, extracts 500/1000 lines and converts the AI result to the original line number
- `src/ai-search.js` - calls OpenAI and verifies the returned line
- `search.js` - single application entry point

Other modules provide configuration, logging and Gutenberg file operations.

Only exported functions are public. Non-exported functions are private to their module.

## Run

```text
node search.js --id 1 --simulate
node search.js --id 1
node search.js --id 1 --model gpt-5.5
node search.js --json books.json --simulate
```

The JSON input may contain the previously planned objects with `id`, `minDate`, `maxDate`, `title`, etc.; currently the processing pipeline uses `id`, leaving the other metadata available for future orchestrator selection rules.

No npm package is required. The implementation uses CommonJS and Node.js built-ins, and is intended for Node.js 16.
